package com.abchina.http;

import io.netty.buffer.ByteBuf;

import javax.servlet.ServletOutputStream;
import javax.servlet.WriteListener;
import java.io.IOException;

/**
 * @author jerrylz
 * @date 2021/3/6
 */
public class ResponseOutPutStream extends ServletOutputStream {

    private ByteBuf byteBuf;

    public ResponseOutPutStream(ByteBuf byteBuf){
        this.byteBuf = byteBuf;
    }


    @Override
    public boolean isReady() {
        return false;
    }

    @Override
    public void setWriteListener(WriteListener writeListener) {

    }

    @Override
    public void write(int b) throws IOException {
        byteBuf.writeByte(b);
    }
}
