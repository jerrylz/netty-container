package com.abchina;

import com.abchina.server.HttpServer;

/**
 * @author jerrylz
 * @date 2021/3/6
 */
public class BootStrap {
    public static void main(String[] args) throws Exception {
        HttpServer httpServer = new HttpServer();
        httpServer.start();
    }
}
