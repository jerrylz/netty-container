var a = 1;
console.log("hello world");
alert("hello world");