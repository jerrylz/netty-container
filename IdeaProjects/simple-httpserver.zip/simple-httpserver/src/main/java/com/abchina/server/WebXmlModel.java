package com.abchina.server;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

/**
 * WebXmlModel.java
 * Created by luckzj
 * 2021-02-20 23:41:57
 * httpserver
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JacksonXmlRootElement(localName = "web-app")
public class WebXmlModel {
    @JacksonXmlProperty(localName = "servlet")
    @JacksonXmlElementWrapper(useWrapping = false)
    private ServletNode[] servletNodes;

    @JacksonXmlProperty(localName = "servlet-mapping")
    @JacksonXmlElementWrapper(useWrapping = false)
    private ServletMappingNode[] servletMappingNodes;

    @JacksonXmlProperty(localName = "display-name")
    private String dispName;

    @JacksonXmlProperty(localName = "port")
    private int port;



    public ServletNode[] getServletNodes() {
        return servletNodes;
    }

    public ServletMappingNode[] getServletMappingNodes() {
        return servletMappingNodes;
    }

    public void setServletNodes(ServletNode[] servletNodes) {
        this.servletNodes = servletNodes;
    }

    public void setServletMappingNodes(ServletMappingNode[] servletMappingNodes) {
        this.servletMappingNodes = servletMappingNodes;
    }

    public String getDispName() {
        return dispName;
    }

    public void setDispName(String dispName) {
        this.dispName = dispName;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ServletNode {
        @JacksonXmlProperty(localName = "servlet-name", isAttribute = false)
        private String servletName;

        @JacksonXmlProperty(localName = "servlet-class")
        private String servletClass;

        @JacksonXmlProperty(localName = "init-param")
        @JacksonXmlElementWrapper(useWrapping = false)
        private ServletInitParam[] servletInitParams;

        public String getServletName() {
            return servletName;
        }

        public void setServletName(String servletName) {
            this.servletName = servletName;
        }

        public String getServletClass() {
            return servletClass;
        }

        public void setServletClass(String servletClass) {
            this.servletClass = servletClass;
        }

        public ServletInitParam[] getServletInitParams() {
            return servletInitParams;
        }

        public void setServletInitParams(ServletInitParam[] servletInitParams) {
            this.servletInitParams = servletInitParams;
        }
    }

    public static class ServletMappingNode {
        @JacksonXmlProperty(localName = "servlet-name")
        private String servletName;

        @JacksonXmlProperty(localName = "url-pattern")
        private String urlPattern;

        public String getServletName() {
            return servletName;
        }

        public void setServletName(String servletName) {
            this.servletName = servletName;
        }

        public String getUrlPattern() {
            return urlPattern;
        }

        public void setUrlPattern(String urlPattern) {
            this.urlPattern = urlPattern;
        }
    }

    public static class ServletInitParam{
        @JacksonXmlProperty(localName = "param-name")
        private String paramName;

        @JacksonXmlProperty(localName = "param-value")
        private String paramValue;

        public String getParamName() {
            return paramName;
        }

        public void setParamName(String paramName) {
            this.paramName = paramName;
        }

        public String getParamValue() {
            return paramValue;
        }

        public void setParamValue(String paramValue) {
            this.paramValue = paramValue;
        }
    }

}
