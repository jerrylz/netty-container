package com.github.netty.protocol.servlet;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @see HttpServletResponse#resetBuffer()
 * @author wangzihaogithub
 * 2020-06-07 00:07:16
 */
public class ServletResetBufferIOException extends IOException {
}
