package com.abchina.server;


import com.abchina.configuration.Configuration;
import com.abchina.handler.HttpRequestHandler;
import com.abchina.handler.RequestDecoderHandler;
import com.abchina.lifecycle.LifeCycle;
import com.abchina.loader.JarClassLoader;
import com.abchina.loader.WebAppLoader;
import com.abchina.utils.LogUtils;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.HttpResponseEncoder;

import java.io.IOException;
import java.util.Map;

public class Context implements LifeCycle {
    private int port;
    private Map<String, ServletWrapper> mapper;
    private String jarName;
    private Configuration configuration;
    private WebAppLoader webAppLoader;
    private ServletContext servletContext;

    private EventLoopGroup bossGroup;
    private EventLoopGroup workGroup;

    @Override
    public void init() throws Exception {
        loadOnStartUpServlet();
//        servletContext = ServletContext.contextWithMapperAndClassLoader(mapper, webAppLoader, jarName);
    }


    @Override
    public void start() {
        ServerBootstrap server = new ServerBootstrap();
        bossGroup = new NioEventLoopGroup();
        workGroup = new NioEventLoopGroup();

        try {
            server.group(bossGroup, workGroup)
                    .channel(NioServerSocketChannel.class)
                    //客户端连接时启动
                    .childHandler(new ChannelInitializer<SocketChannel>() {
                        protected void initChannel(SocketChannel client) throws Exception {
                            //响应编码器
                            client.pipeline().addLast(new HttpResponseEncoder());
                            //请求解码器
                            client.pipeline().addLast(new RequestDecoderHandler());
                            //自定义处理器
                            client.pipeline().addLast(new HttpRequestHandler(mapper));

                        }
                    })
                    .option(ChannelOption.SO_BACKLOG, 128)
                    .childOption(ChannelOption.SO_KEEPALIVE, true);
            ChannelFuture f = server.bind(port).sync();
            LogUtils.info(HttpServer.class, "HttpServer 已启动");
            //监听关闭状态启动
            f.channel().closeFuture().sync();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }finally {
            //关闭线程池
            bossGroup.shutdownGracefully();
            workGroup.shutdownGracefully();
        }
    }


    @Override
    public void destroy() throws IOException {
        //关闭线程池
        bossGroup.shutdownGracefully();
        workGroup.shutdownGracefully();
    }


    public Context(String jarName, Configuration configuration) throws Exception {
        this.jarName = jarName;
        this.configuration = configuration;
        this.mapper = configuration.getRouter();
        this.port = configuration.getPort();
        JarClassLoader jarClassLoader = new JarClassLoader(jarName);
        this.webAppLoader = new WebAppLoader(mapper, jarClassLoader);


    }

    public ServletContext getServletContext() {
        return servletContext;
    }

    Map<String, ServletWrapper> getMapper() {
        return mapper;
    }

    private void loadOnStartUpServlet() throws Exception {
        webAppLoader.loadOnStartUp();
    }

    public void setPort(int port) {
        this.port = port;
    }


}
