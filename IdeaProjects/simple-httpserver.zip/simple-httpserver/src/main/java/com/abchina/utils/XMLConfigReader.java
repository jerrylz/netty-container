package com.abchina.utils;


import com.abchina.configuration.Configuration;
import com.abchina.server.ServletWrapper;
import com.abchina.server.WebXmlModel;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * @author jerrylz
 * @date 2021/3/6
 */
public class XMLConfigReader {

    public Configuration parseXmlFileAsConfiguration(InputStream in) throws IOException {
        XmlMapper xmlMapper = new XmlMapper();
        WebXmlModel webXmlModel = xmlMapper.readValue(in, WebXmlModel.class);
        Configuration configuration = parseModelAsConfiguration(webXmlModel);
        return configuration;
    }

    private Configuration parseModelAsConfiguration(WebXmlModel webXmlModel) {
        WebXmlModel.ServletMappingNode[] servletMappingNodes = webXmlModel.getServletMappingNodes();
        Map<String, String> mappingNodes = new HashMap<>();
        for(WebXmlModel.ServletMappingNode servletMappingNode : servletMappingNodes){
            mappingNodes.put(servletMappingNode.getServletName(), servletMappingNode.getUrlPattern());
        }
        WebXmlModel.ServletNode[] servletNodes = webXmlModel.getServletNodes();

        Map<String, ServletWrapper> router = new HashMap<>();
        for(WebXmlModel.ServletNode node : servletNodes){
            String servletClass = node.getServletClass();
            String servletName = node.getServletName();
            Map<String, String> initParamMap = new HashMap<>();
            for(WebXmlModel.ServletInitParam servletInitParam : node.getServletInitParams()){
                initParamMap.put(servletInitParam.getParamName(), servletInitParam.getParamValue());
            }

            ServletWrapper wrapper = new ServletWrapper(servletName,
                    mappingNodes.get(servletName),
                    servletClass,
                    0, null, null, initParamMap);
            router.put(mappingNodes.get(servletName), wrapper);

        }

        Configuration configuration = new Configuration(router);
        configuration.setPort(webXmlModel.getPort());

        return configuration;

    }
}
