package com.abchina.http.exception;

public class RequestParseException extends Exception {
    public RequestParseException(String message) {
        super(message);
    }
}
