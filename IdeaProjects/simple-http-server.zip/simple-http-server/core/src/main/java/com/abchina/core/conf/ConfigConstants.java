package com.abchina.core.conf;

public class ConfigConstants {

    public static final String PORT = "port";
    public static final String SUB_REACTOR_COUNT = "subReactorCount";
    public static final String ROUTER = "router";
    public static final String SERVLET_NAME = "servlet-name";
    public static final String PATH = "path";
    public static final String SERVLET_CLASS = "servlet-class";
    public static final String LOAD_ON_STARTUP = "load-on-startup";

}
