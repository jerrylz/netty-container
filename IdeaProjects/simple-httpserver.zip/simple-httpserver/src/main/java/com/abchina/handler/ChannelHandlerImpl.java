package com.abchina.handler;

import io.netty.channel.Channel;
import io.netty.channel.ChannelInitializer;

/**
 * @author jerrylz
 * @date 2021/3/6
 */
public class ChannelHandlerImpl extends ChannelInitializer {
    @Override
    protected void initChannel(Channel client) throws Exception {
        //响应编码器
//        client.pipeline().addLast(new HttpResponseEncoder());
        //请求解码器
//        client.pipeline().addLast(new HttpRequestDecoder());
        //进一步包装请求
        client.pipeline().addLast(new RequestDecoderHandler());
        //自定义处理器
//        client.pipeline().addLast(new HttpRequestHandler());
    }
}
