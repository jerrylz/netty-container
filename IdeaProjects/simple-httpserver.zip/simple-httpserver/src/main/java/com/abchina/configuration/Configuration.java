package com.abchina.configuration;


import com.abchina.server.ServletWrapper;
import com.abchina.utils.EqualsUtils;

import java.util.Map;

public class Configuration {
    private int port;
    private Map<String, ServletWrapper> router;

    public Configuration(Map<String, ServletWrapper> router) {
        this(8080, router);
    }

    public Configuration(int port, Map<String, ServletWrapper> router) {
        this.port = port;
        this.router = router;
    }


    public Map<String, ServletWrapper> getRouter() {
        return router;
    }

    public int getPort() {
        return port;
    }


    public void setPort(int port) {
        this.port = port;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Configuration)) {
            return false;
        }

        Configuration that = (Configuration) obj;
        try {
            return EqualsUtils.OneDepthContentEquals(this, that);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return false;
    }
}
