package com.abchina.server;

import com.abchina.handler.RequestDecoderHandler;
import com.abchina.http.Request;
import com.abchina.http.RequestFacade;
import com.abchina.http.ResponseFacade;
import com.abchina.lifecycle.LifeCycle;
import com.abchina.loader.ContextLoader;
import com.abchina.utils.LogUtils;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.ByteBufAllocator;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.HttpResponseEncoder;

import javax.servlet.http.HttpServlet;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * @author jerrylz
 * @date 2021/2/26
 */
public class HttpServer implements LifeCycle {

    private static final String BUILD_PATH = "/build";

    private final ContextLoader contextLoader;

    private List<Context> contexts;
    private List<ServerSource> sources;

    public HttpServer() throws Exception {
        this(BUILD_PATH);
    }

    public HttpServer(String buildPath) throws Exception {
        contextLoader = new ContextLoader(buildPath, this);
        init();
    }

    @Override
    public void init() throws Exception {
        LogUtils.info(HttpServer.class, "初始化应用环境");
        //加载应用上下文
        contextLoader.load();
    }

    @Override
    public void start() throws Exception {
        for (Context context : contexts) {
            context.init();
            context.start();
        }
        LogUtils.info(HttpServer.class, "服务启动完成");
    }

    @Override
    public void destroy() throws Exception {
        for(Context context : contexts){
            context.destroy();
        }
    }

    public void clear() throws IOException {
        for (Context context : contexts) {
            context.destroy();
        }
        contexts.clear();
        sources.clear();
    }

    public ContextLoader getContextLoader() {
        return contextLoader;
    }

    public List<Context> getContexts() {
        return contexts;
    }

    public void setContexts(List<Context> contexts) {
        this.contexts = contexts;
    }

    public List<ServerSource> getSources() {
        return sources;
    }

    public void setSources(List<ServerSource> sources) {
        this.sources = sources;
    }


    //    private int port = 9099;
//    private Map<String, HttpServlet> servletMapping = new HashMap<>();
//    private Properties webxml = new Properties();
//
//    private void init() {
//        try {
//            //初始化 读取配置
//            String WEB_INF = this.getClass().getResource("/").getPath();
//            FileInputStream fis = new FileInputStream(WEB_INF + "web.properties");
//            webxml.load(fis);
//
//            for (Object k : webxml.keySet()) {
//                String key = k.toString();
//                if (key.endsWith("url")) {
//                    String servletName = key.replaceAll("\\.url$", "");
//                    String url = webxml.getProperty(key);
//                    String className = webxml.getProperty(servletName + ".className");
//                    HttpServlet servlet = (javax.servlet.http.HttpServlet) Class.forName(className).newInstance();
//                    servletMapping.put(url, servlet);
//                }
//            }
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        } catch (IllegalAccessException e) {
//            e.printStackTrace();
//        } catch (InstantiationException e) {
//            e.printStackTrace();
//        } catch (ClassNotFoundException e) {
//            e.printStackTrace();
//        }
//    }
//
//    public void start() {
//        doStart();
//    }
//
//    public void start(int port) {
//        this.port = port;
//        doStart();
//    }
//
//    private void doStart() {
//        init();
//        EventLoopGroup bossGroup = new NioEventLoopGroup();
//        EventLoopGroup workGroup = new NioEventLoopGroup();
//        ServerBootstrap server = new ServerBootstrap();
//        try {
//            server.group(bossGroup, workGroup)
//                    .channel(NioServerSocketChannel.class)
//                    //客户端连接时启动
//                    .childHandler(new ChannelInitializer<SocketChannel>() {
//                        protected void initChannel(SocketChannel client) throws Exception {
//                            //响应编码器
//                            client.pipeline().addLast(new HttpResponseEncoder());
//                            //请求解码器
////                            client.pipeline().addLast(new HttpRequestDecoder());
//                            //进一步包装请求
//                            client.pipeline().addLast(new RequestDecoderHandler());
//                            //自定义处理器
//                            client.pipeline().addLast(new HttpRequestHandler());
//
//                        }
//                    })
//                    .option(ChannelOption.SO_BACKLOG, 128)
//                    .childOption(ChannelOption.SO_KEEPALIVE, true);
//            ChannelFuture f = server.bind(port).sync();
//            LogUtils.info(HttpServer.class, "HttpServer 已启动");
//            //监听关闭状态启动
//            f.channel().closeFuture().sync();
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }finally {
//            //关闭线程池
//            bossGroup.shutdownGracefully();
//            workGroup.shutdownGracefully();
//        }
//    }
//
//    //处理请求
//    public class HttpRequestHandler extends ChannelInboundHandlerAdapter {
//        @Override
//        public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
//            ByteBufAllocator alloc = ctx.alloc();
//            if(msg instanceof Request){
//                Request req = (Request) msg;
//                RequestFacade requestFacade = new RequestFacade(req);
//
//                ResponseFacade responseFacade = new ResponseFacade(ctx);
//
//                String url = requestFacade.getRequestURI();
//                if(servletMapping.containsKey(url)){
//                    servletMapping.get(url).service(requestFacade,responseFacade);
//                }else{
//                    responseFacade.getChannelHandlerContext().write("404");
//                }
//            }
//        }
//
//        @Override
//        public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
//            super.exceptionCaught(ctx, cause);
//        }
//    }


}
