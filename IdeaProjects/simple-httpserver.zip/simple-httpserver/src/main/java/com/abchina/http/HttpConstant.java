package com.abchina.http;

/**
 * @author jerrylz
 * @date 2021/3/1
 */
public class HttpConstant {

//    public static final String
}
