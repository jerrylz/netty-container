package com.abchina.http;

import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.abchina.utils.LogUtils;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * @author jerrylz
 * @date 2021/3/1
 */
public class RequestWrapper {

    private static final String CRLF = "\r\n";
    private static final String SP = " ";
    private static final String HEADER_SP = ": ";
    //请求行
    private Map<String, String> requestLineMap = new HashMap<>();
    //请求头
    private Map<String, String> requestHeaderMap = new HashMap<>();
    //参数
    private Map<String, String> parameterMap = new HashMap<>();

    private String method;
    private String url;


    public void parseRequestInfo(String requestInfo){
        if(StrUtil.isBlank(requestInfo)){
            return;
        }

        String[] reqArray = StrUtil.split(requestInfo, CRLF);
        if(reqArray.length > 0){
            //解析请求行
            parseRequestLine(reqArray[0]);
        }
        //请求体索引
        int bodyIndex = 0;
        for(int i = 1; i < reqArray.length; i++){
            //空白行跳出循环
            if(StrUtil.isBlank(reqArray[i])){
                bodyIndex = ++i;
                break;
            }
            //非空白行，则解析请求头
            parseRequestHeader(reqArray[i]);
        }

        if(bodyIndex < reqArray.length){
            String bodyString = reqArray[bodyIndex];
            if ("application/json".equals(requestHeaderMap.get("Content-Type"))){
                parseJsonParam(bodyString);
            }else if(StrUtil.contains(requestHeaderMap.get("Content-Type"), "multipart/form-data")){
                LogUtils.warn(RequestWrapper.class, "暂不支持");
            }else{
                parseNonJsonParam(bodyString);
            }
        }

    }

    private void parseJsonParam(String body) {
        JSONObject obj = JSONUtil.parseObj(body);
        for(String key : obj.keySet()){
            this.parameterMap.put(key, obj.getStr(key));
        }
    }

    /**
     * 解析请求行
     * @param requestLine
     */
    private void parseRequestLine(String requestLine) {
        //请求行格式GET /do HTTP/1.1
        //以空格分割
        String[] lineArray = StrUtil.split(requestLine, SP);
        for(int i = 0; i < lineArray.length; i++){
            if(i == 0){
                this.method = lineArray[0].trim();
                this.requestLineMap.put("method",lineArray[0].trim());
            }else if(i == 1){
                String urlString = lineArray[1].trim();
                String paraString = "";
                //GET包含请求参数
                if ("get".equalsIgnoreCase(this.method)) {
                    //包含有问号，说明有参数
                    if (urlString.contains("?")) {
                        //以?号分割获取参数
                        String[] urlArray = urlString.split("\\?");
                        this.url = urlArray[0];
                        //解析参数
                        parseNonJsonParam(urlArray[1]);
                    } else {
                        this.url = urlString;
                    }
                } else {
                    //POST不包含请求参数,参数在请求正文
                    this.url = urlString;
                }
                this.requestLineMap.put("url", urlString);
            }else if(i == 2){
                this.requestLineMap.put("httpVersion", lineArray[2].trim());
            }
        }
    }

    private void parseNonJsonParam(String prarString) {
        String[] token = prarString.split("&");
        for (String keyValues : token) {
            String[] keyValue = keyValues.split("=");
            if (keyValue.length == 1) {  //username=
                keyValue = Arrays.copyOf(keyValue, 2);
                keyValue[1] = null;
            }
            //将表单元素的name与name对应的值存储到Map集合
            String key = keyValue[0].trim();
            String value = keyValue[1] == null ? null : decode(keyValue[1].trim(), "utf-8");
            //放到集合中存储
//            if (!parameterMap.containsKey(key)) {
//                parameterMap.put(key, new ArrayList<String>());
//            }
//            List<String> values = parameterMap.get(key);
//            values.add(value);
            parameterMap.put(key, value);
        }
    }

    /**
     * 解析请求头数据
     * @param requestHeader
     */
    private void parseRequestHeader(String requestHeader){
        //请求头格式 XXX:XXX
        String[] headerArray = StrUtil.split(requestHeader, HEADER_SP);
        this.requestHeaderMap.put(headerArray[0], headerArray[1]);
    }

    //处理中文，因类浏览器对中文进行了编码，进行解码
    private String decode(String value, String code) {
        try {
            return URLDecoder.decode(value, code);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Map<String, String> getRequestLineMap() {
        return requestLineMap;
    }

    public Map<String, String> getRequestHeaderMap() {
        return requestHeaderMap;
    }

    public Map<String, String> getParameterMap() {
        return parameterMap;
    }

    public String getMethod() {
        return method;
    }


    public String getUrl() {
        return url;
    }

}
