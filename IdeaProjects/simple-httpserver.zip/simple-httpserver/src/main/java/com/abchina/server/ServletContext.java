package com.abchina.server;


import cn.hutool.db.Session;
import com.abchina.loader.WebAppLoader;

import java.io.File;
import java.nio.channels.SocketChannel;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ServletContext {
    private SocketChannel channel;
    private Map<String, ServletWrapper> mapper;
    private WebAppLoader loader;
    private final File jarFile;

    private Map<String, Session> sessionMap = new ConcurrentHashMap<>();


    public ServletContext(SocketChannel channel, Map<String, ServletWrapper> mapper, WebAppLoader loader, String jarName) {
        this.channel = channel;
        this.mapper = mapper;
        this.loader = loader;
        this.jarFile = new File("build/" + jarName);
    }

    public void start(){

    }


    public static ServletContext emptyContext() {
        return new ServletContext(null, null, null, null);
    }

    public static ServletContext contextWithMapperAndClassLoader(Map<String, ServletWrapper> mapper, WebAppLoader loader, String jarName) {
        return new ServletContext(null, mapper, loader, jarName);
    }


    SocketChannel getChannel() {
        return channel;
    }

    public void setChannel(SocketChannel channel) {
        this.channel = channel;
    }

    public Map<String, ServletWrapper> getMapper() {
        return mapper;
    }

    public WebAppLoader getLoader() {
        return loader;
    }

    public File getJarFile() {
        return jarFile;
    }

    public void setMapper(Map<String, ServletWrapper> mapper) {
        this.mapper = mapper;
    }

    public void setLoader(WebAppLoader loader) {
        this.loader = loader;
    }

    public Map<String, Session> getSessionMap() {
        return sessionMap;
    }

    public void setSessionMap(Map<String, Session> sessionMap) {
        this.sessionMap = sessionMap;
    }
}
