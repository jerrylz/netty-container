package com.abchina.handler;

import com.abchina.http.Request;
import com.abchina.http.RequestFacade;
import com.abchina.http.ResponseFacade;
import com.abchina.server.ServletWrapper;
import com.abchina.server.impl.NotFoundServlet;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufAllocator;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

import javax.servlet.Servlet;
import java.util.Map;

/**
 * @author jerrylz
 * @date 2021/3/6
 */
public class HttpRequestHandler extends ChannelInboundHandlerAdapter {

    private Map<String, ServletWrapper> servletWrapperMap;

    public HttpRequestHandler(Map<String, ServletWrapper> servletWrapperMap){
        this.servletWrapperMap = servletWrapperMap;
    }
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        if(msg instanceof Request){
            Request req = (Request) msg;
            RequestFacade requestFacade = new RequestFacade(req);

            ResponseFacade responseFacade = new ResponseFacade(ctx);

            String url = requestFacade.getRequestURI();
            if(servletWrapperMap.containsKey(url)){
                ServletWrapper servletWrapper = servletWrapperMap.get(url);
                Servlet servlet = servletWrapper.getServlet();
                if(servlet == null){
                    Class<? extends Servlet> servletClass = servletWrapper.getServletClass();
                    servlet = servletClass.newInstance();
                }
                servlet.service(requestFacade,responseFacade);
            }else{
                NotFoundServlet notFoundServlet = new NotFoundServlet();
                notFoundServlet.service(requestFacade, responseFacade);
            }
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        super.exceptionCaught(ctx, cause);
    }
}
