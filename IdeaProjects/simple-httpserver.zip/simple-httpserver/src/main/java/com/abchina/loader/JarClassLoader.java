package com.abchina.loader;

import com.abchina.utils.FileUtils;

import java.net.URLClassLoader;

public class JarClassLoader extends URLClassLoader {

    public JarClassLoader(String jarPath) throws Exception {
        super(FileUtils.parseSinglePathToUrls(jarPath));
    }

}
