package com.abchina.core.scanner;

public interface Event {
}
